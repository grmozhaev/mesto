// Для удобного тиражирования одинаковых объектов
// Воспользуйтесь `<template>` -- https://developer.mozilla.org/ru/docs/Web/HTML/Element/template
// И `cloneNode` -- https://developer.mozilla.org/ru/docs/Web/API/Node/cloneNode
